CREATE UNIQUE CLUSTERED INDEX IX_Players_PlayerId
ON Wrox_Golf_Results.dbo.Players 
   (Player_Id)
ON [PRIMARY]

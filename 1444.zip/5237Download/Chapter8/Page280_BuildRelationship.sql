USE Wrox_Golf_Results
GO
CREATE UNIQUE INDEX IX_Matches_MatchId 
   ON Matches ([Match_Id]) ON [PRIMARY]
GO
ALTER TABLE Match_Scores 
   ADD CONSTRAINT [FK_Match_Scores_Matches] FOREIGN KEY 
                  (Match_Id) 
   REFERENCES [Matches] ([Match_Id])
GO

-- Page 516 : Try It Out - Indexing a View

-- BULLET POINT 1

CREATE UNIQUE CLUSTERED INDEX IXvwBalances
ON vwSociety_Groups_Balances 
   (Society_Group_Id)
GO

-- BULLET POINT 4

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
DROP VIEW vwPlayers_Details
GO
CREATE VIEW vwPlayers_Details WITH SCHEMABINDING
AS
SELECT Players.Player_First_Name, Players.Player_Last_Name, Players.Games_played, 
       Players.Points_Scored, Society_Groups.Society_Group_Desc
FROM   dbo.Players, dbo.Society_Groups 
WHERE  Players.Society_Group = Society_Groups.Society_Group_Id

GO
CREATE UNIQUE CLUSTERED INDEX ixPlayers_Details ON vwPlayers_Details (Player_First_Name, Player_Last_Name)
go
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





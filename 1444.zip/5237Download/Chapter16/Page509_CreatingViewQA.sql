
-- **********************************
-- *================================*
-- *           CHAPTER 16           *
-- *================================*
-- **********************************



-- PAGE 509 : Try It Out - Creating a View in Query Analyzer

-- BULLET POINT 2

CREATE VIEW dbo.vwMatches
AS
SELECT TOP 100 PERCENT Society_Group_Id, Match_Id, Date_Played, Opposition_Name, 
                       Home, Points_For, Points_Against
FROM dbo.Matches
ORDER BY Date_Played DESC
  


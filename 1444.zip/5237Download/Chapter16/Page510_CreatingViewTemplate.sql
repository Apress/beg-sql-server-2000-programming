-- Page 510 : Try It Out - Creating a View with a Template


-- BULLET POINT 3


-- =============================================
-- Create schemabinding view
-- =============================================
IF EXISTS (SELECT TABLE_NAME 
   FROM   INFORMATION_SCHEMA.VIEWS 
   WHERE  TABLE_NAME = 'vwSociety_Groups_Balances')
   DROP VIEW vwSociety_Groups_Balances
GO

CREATE VIEW vwSociety_Groups_Balances WITH SCHEMABINDING
AS 
   SELECT Society_Group_Id, Society_Group_Desc, Bank_Balance, 
      (SELECT COUNT(*) FROM dbo.Players 
         WHERE Society_Group = Society_Group_Id) AS No_Of_Players
      FROM dbo.Society_Groups
GO

-- BULLET POINT 4

-- =============================================
-- Create schemabinding view
-- =============================================
IF EXISTS (SELECT TABLE_NAME 
   FROM   INFORMATION_SCHEMA.VIEWS 
   WHERE  TABLE_NAME = 'vwSociety_Groups_Balances')
   DROP VIEW vwSociety_Groups_Balances
GO

CREATE VIEW vwSociety_Groups_Balances WITH SCHEMABINDING
AS 
   SELECT Society_Group_Id, Society_Group_Desc, Bank_Balance, 
      (SELECT COUNT(*) FROM dbo.Players 
         WHERE Society_Group = Society_Group_Id) AS No_Of_Players
      FROM dbo.Society_Groups
GO

-- BULLET POINT 6

ALTER TABLE Society_Groups 
ALTER COLUMN Society_Group_Desc varchar (30) NOT NULL 
GO

-- BULLET POINT 8

SELECT * 
FROM vwSociety_Groups_Balances 
WHERE No_Of_Players > 0


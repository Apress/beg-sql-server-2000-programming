-- Page 514 : Try It Out - Setting Permissions on a View

-- BULLET POINT 1

GRANT ALL
   ON vwPlayers_Details
   TO Developers
GO

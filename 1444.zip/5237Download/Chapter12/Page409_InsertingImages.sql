--------------------------------------------
-- Page 409 : Try It Out - Inserting Images
--------------------------------------------


-- BULLET POINT 2

SET QUOTED_IDENTIFIER OFF
GO
USE Wrox_Golf_Results
GO
INSERT INTO Players
(Society_Group,Player_First_Name, Player_Last_Name,Photograph,Date_Of_Birth)
VALUES (1,"Annette","Kelly",0xFFFFFFFF,"23 Sep 73")


-- BULLET POINT 6

DECLARE @Pointer_Value varbinary(16)
SELECT @Pointer_Value = TEXTPTR(Photograph)
FROM Players
WHERE Player_ID = 1
WRITETEXT Players.Photograph @Pointer_Value 
   "C:\Program Files\Microsoft SQL Server\
      MSSQL\Data\Wrox_Golf_Results\Images\ak.bmp"

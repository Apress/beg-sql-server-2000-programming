---------------------------------------------------------
-- Page 413 : Try It Out - Insert Several Records At Once
---------------------------------------------------------

SET QUOTED_IDENTIFIER OFF
GO
INSERT INTO Society_Groups (Society_Group_Desc, Society_Leader_Name)
   VALUES("The Upmarket Traders","Jason Atkins")
INSERT INTO Society_Groups (Society_Group_Desc, Society_Leader_Name)
   VALUES("Gilbert's Golfers","Martin Aynsley")
GO
INSERT INTO Society_Groups (Society_Group_Desc, Society_Leader_Name)
   VALUES("Security Blankets","Dave Shawl")
INSERT INTO Society_Groups (Society_Group_Desc, Society_Leader_Name)
   VALUES("The Chieftan Coach","Colin Jackson")
GO

-- BULLET POINT 4

INSERT INTO Players
(Society_Group,Player_First_Name, Player_Last_Name,Photograph,Date_Of_Birth)
VALUES (3,"Jason","Atkins",0xFFFFFFFF,"15 Oct 81")

DECLARE @Pointer_Value varbinary(16)
SELECT @Pointer_Value = TEXTPTR(Photograph)
FROM Players
WHERE Player_ID = 2
WRITETEXT Players.Photograph @Pointer_Value 
   "C:\Program Files\Microsoft SQL Server\
      MSSQL\Data\Wrox_Golf_Results\Images\ja.bmp"

INSERT INTO Players
(Society_Group,Player_First_Name, Player_Last_Name,Photograph,Date_Of_Birth)
VALUES (2,"Ian","McMahon",0xFFFFFFFF,"3 Feb 82")

SELECT @Pointer_Value = TEXTPTR(Photograph)
FROM Players
WHERE Player_ID = 3
WRITETEXT Players.Photograph @Pointer_Value 
   "C:\Program Files\Microsoft SQL Server\
      MSSQL\Data\Wrox_Golf_Results\Images\im.bmp"


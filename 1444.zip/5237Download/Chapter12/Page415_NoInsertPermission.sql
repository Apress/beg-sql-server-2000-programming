------------------------------------
-- Page 415 : NO INSERTS PERMISSIONS
------------------------------------

-- BULLET POINT 6


SET QUOTED_IDENTIFIER OFF
GO
Insert Into dbo.Players
(Society_Group,Player_First_Name,Player_Last_Name,
Date_Of_Birth) values (1,"Lee","Smith","1 Mar 1954")


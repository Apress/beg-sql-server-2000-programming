
---------------------------------------------
-- Page 399 : DBBCC CHECKIDENT
---------------------------------------------

DELETE FROM Society_Groups
DBCC CHECKIDENT (Society_Groups,RESEED,0)

INSERT INTO Society_Groups (Society_Group_Desc, Society_Leader_Name) 
VALUES('Kojak Team','Annnette Kelly')

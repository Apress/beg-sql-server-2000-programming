------------------------------------------------------------------------
-- Page 400 : Try It Out - Inserting With Default Values: Query Analyzer
------------------------------------------------------------------------


SET QUOTED_IDENTIFIER OFF
USE Wrox_Golf_Results
GO
INSERT into Society_Groups
(Society_Group_Desc)
VALUES ("Bedford Junior Blues")

-- BULLET POINT 4

USE Wrox_Golf_Results
GO
INSERT into Society_Groups
(Society_Group_Id, Society_Group_Desc)
VALUES (20, "Bedford Junior Blues")


-- BULLET POINT 6

USE Wrox_Golf_Results
GO
INSERT INTO Society_Groups
(Society_Leader_Name, Society_Group_Desc)
VALUES ("Jack Mason", "Bedford Junior Blues")


-- Page 391 Bullet Points 5 and 6

SET QUOTED_IDENTIFIER OFF
GO


INSERT INTO [Wrox_Golf_Results].[dbo].[Club_Details]([Club_Name], [Address], 
[Phone_Number], [Fax_Number], [Club_Email], [Web_Site], [Last_Updated], 
[Zip_Code], [State_US_Only], [Country], [Club_Chairperson], [Club_ViceChair], [Club_Secretary])
VALUES("Bedford Golf Society","c/o Bedford Golf Club, Wenworth Drive, Bedford, Beds.", 
"No phone", "No Fax", "bedford@wrox-golf.co.uk", "www.wrox-golf.co.uk", "12 May 2001",
"MK41 0PU", NULL, 42, "Andy Illingworth", "", "Lee Smith")


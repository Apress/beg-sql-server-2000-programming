-------------------------------------------------------------------------------
-- Page 403 : Try It Out - Altering a Table for a Default Value: Query Analyzer
-------------------------------------------------------------------------------

USE Wrox_Golf_Results
GO
-- This will add a primary key to the Players table
ALTER TABLE dbo.Players ADD CONSTRAINT
   PK_Players PRIMARY KEY NONCLUSTERED 
   (
      Player_Id
   ) ON [PRIMARY]
GO



-- BULLET POINT 3

/*
 This will ensure that when the Points_Scored column is updated
 the value will be positive
*/
ALTER TABLE dbo.Players WITH NOCHECK ADD CONSTRAINT
   CK_Players_PointsCheck CHECK (([points_scored] >= 0))
GO

-- BULLET POINT 4

-- This will add a default value of 0 if no value specified
ALTER TABLE Players WITH NOCHECK
   ADD CONSTRAINT DF_Players_Games_Played DEFAULT (0) FOR Games_Played
GO

-- BULLET POINT 5

-- This will add a default value of 0 if no value specified
ALTER TABLE Players WITH NOCHECK
   ADD CONSTRAINT DF_Players_Points_Scored DEFAULT (0) FOR Points_Scored
GO

-- BULLET POINT 6

-- This will add a default value of 0 if no value specified
ALTER TABLE Players WITH NOCHECK
   ADD CONSTRAINT DF_Players_Left_Club DEFAULT (0) FOR Has_Left_The_Club 
GO

-- BULLET POINT 13

INSERT INTO Players(Society_Group, Player_First_Name, Player_Last_Name, Date_Of_Birth, Games_played, Points_Scored, Has_Left_The_Club)
VALUES (1, "Daniel", "Tarbotton", "24 Mar 1964", 1, -3, 0)


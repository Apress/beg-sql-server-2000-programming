-- Page 393 - ALLOWING NULLs and the ALLOW NULLS option

INSERT Club_Details (Club_Name, Address, Country) 
VALUES ('Bedford Golf Society','c/o Before Golf Club, Wenworth Drive, Bedford, Beds.',0) 
INSERT Club_Details (Club_Name, Address, Country) 
VALUES ('Bedford Golf Society','c/o Before Golf Club, Wenworth Drive, Bedford, Beds.',0)

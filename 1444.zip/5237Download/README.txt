

Welcome to the code download for Beginning SQL Server 2000 Programming.

The code is organised into the relevant chapter folders, and within these folders, the
code is split into files with the following naming convention:

                         PageN_Description.sql

where N is the Page number in the book at which the code starts, and Description is a short
description of the code. 

Note that if code is  part of a Try It Out that lasts several pages, each step of the Try It Out
is in contained in the same file, and these steps are separated by -- BULLET POINT comments, marking
which parts of the code correspond exactly to the text.

To use the code, Select File|Open from Query Analyzer and select the required file. To execute
individual parts of the code in order to follow the steps in a Try It Out say, highlight the 
relevant part of the code and click on the Execute button.

The bitmaps that feature in Chapters 12-14 are included in the Bitmaps folder.


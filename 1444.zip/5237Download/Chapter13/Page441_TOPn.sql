-----------------------------------
-- page 441 : Try It Out - Top n
-----------------------------------

SELECT TOP 3 * FROM Society_Groups
SET ROWCOUNT 3
SELECT TOP 2 * FROM Society_Groups
SET ROWCOUNT 2
SELECT TOP 3 * FROM Society_Groups
SET ROWCOUNT 0
SELECT TOP 3 * FROM Society_Groups WHERE SOCIETY_GROUP_ID < 6 
ORDER BY SOCIETY_GROUP_ID DESC

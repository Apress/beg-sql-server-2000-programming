-------------------------------------------
-- Page 436 : Try It Out - String Functions
-------------------------------------------

-- BULLET POINT 2

SELECT RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) 
AS "Player name", Games_Played AS "Pld",Points_Scored AS "Scored" 
FROM Players

-- BULLET POINT 4

SELECT LEFT(RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name),30) 
AS "Player name", Games_Played AS "Pld",Points_Scored AS "Scored" 
FROM Players
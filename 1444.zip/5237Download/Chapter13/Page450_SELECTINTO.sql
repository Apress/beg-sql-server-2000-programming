--------------------------------------
-- Page 450 : Try It Out - SELECT INTO
--------------------------------------

-- BULLET POINT 1

SELECT Society_Group_Id, Society_Group_Desc, Society_Leader_Name
INTO Society_Group_Temp
FROM Society_Groups
WHERE Society_Group_Id > 1 

-- BULLET POINT 4

SELECT * FROM Society_Group_Temp

-- BULLET POINT 6
-- SAME AS BULLET POINT 1 CODE!

SELECT Society_Group_Id, Society_Group_Desc, Society_Leader_Name
INTO Society_Group_Temp
FROM Society_Groups
WHERE Society_Group_Id > 1


----------------------------------------------
-- Page 431 : Try It Out - The WHERE Statement
----------------------------------------------

-- BULLET POINT 2

SET QUOTED_IDENTIFIER OFF
GO
SELECT * FROM Society_Groups
WHERE Society_Group_Desc = "Gilbert's Golfers"

-- BULLET POINT 5

SELECT * FROM Society_Groups
WHERE Society_Leader_Name > "Jack"

-- BULLET POINT 7

SELECT * FROM Society_Groups
WHERE Society_Leader_Name < "Jack"

-- BULLET POINT 9

SELECT * FROM Society_Groups
WHERE Society_Group_Id <> 4 AND Society_Group_Id <> 6

SELECT * FROM Society_Groups
WHERE NOT Society_Group_Id = 4 AND NOT Society_Group_Id = 6

-- BULLET POINT 11

SELECT Society_Leader_Name
FROM Society_Groups
WHERE Society_Leader_Name > "Colin" AND Society_Leader_Name < "Martin"

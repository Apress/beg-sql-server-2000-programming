--------------------------------------------
-- Page 444 : Try It Out - The LIKE Operator
--------------------------------------------

-- BULLET POINT 1

SELECT RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) As Player_Found
FROM Players
WHERE UPPER(Player_Last_Name) LIKE "%KINS"

-- BULLET POINT 3

SELECT RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) As Player_Found
FROM Players
WHERE UPPER(Player_First_Name) like "%O%"
   OR UPPER(Player_Last_Name) like "%O%"

-- BULLET POINT 5

SELECT RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) As Player_Found
FROM Players
WHERE  UPPER(Player_Found) like "%O%"

-- BULLET POINT 10

SELECT RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) AS "Player" 
FROM Players WHERE 
RTRIM(Player_First_Name) + " " + RTRIM(Player_Last_Name) LIKE "%[k-l]%"

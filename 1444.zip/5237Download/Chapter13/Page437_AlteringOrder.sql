--------------------------------------------
-- Page 437 : Try It Out - Altering the Order
--------------------------------------------


-- BULLET POINT 1

SET QUOTED_IDENTIFIER OFF
GO
INSERT INTO Players (Society_Group, Player_First_Name, Player_Last_Name,
   Date_Of_Birth) VALUES(1,"Andrew","Kelly","12 Jan 1976")
INSERT INTO Players (Society_Group, Player_First_Name, Player_Last_Name,
   Date_Of_Birth) VALUES(2,"Justin","Mason","12 Jan 1976")
INSERT INTO Players (Society_Group, Player_First_Name, Player_Last_Name,
   Date_Of_Birth) VALUES(1,"Andy","Mackay","12 Jan 1976")
INSERT INTO Players (Society_Group, Player_First_Name, Player_Last_Name,
   Date_Of_Birth) VALUES(1,"Martin","Price","12 Jan 1976")
INSERT INTO Players (Society_Group, Player_First_Name, Player_Last_Name,
   Date_Of_Birth) VALUES(3,"Ian","Prentice","12 Jan 1976")


-- BULLET POINT 3


SELECT LEFT(Player_First_Name,1) + " " + Player_Last_Name AS Name
FROM Players 
ORDER BY Player_Last_Name


-- BULLET POINT 5

SELECT LEFT(Player_First_Name,1) + " " + Player_Last_Name AS Name
FROM Players 
ORDER BY Player_Last_Name DESC

-- BULLET POINT 7

SELECT LEFT(Player_First_Name,1) + " " + Player_Last_Name AS Name
FROM Players 
ORDER BY LEFT(Player_First_Name,1), Player_Last_Name DESC

-- BULLET POINT 9

SELECT LEFT(Player_First_Name,1) + " " + Player_Last_Name AS Name
FROM Players 
ORDER BY LEFT(Player_First_Name,1) DESC, Player_Last_Name
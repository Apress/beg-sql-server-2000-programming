---------------------------------------------
-- Page 453 : Try It Out - Joining Two Tables
---------------------------------------------

-- BULLET POINT 1

SELECT sg.Society_Group_Id "ID", sg.Society_Group_Desc "Society",
   RTRIM(pl.Player_First_Name) + " " + pl.Player_Last_Name AS "Name", 
   pl.Date_Of_Birth AS "DOB"
FROM Society_Groups sg INNER JOIN Players pl
ON sg.Society_Group_Id = pl.Society_Group

-- BULLET POINT 2

SELECT sg.Society_Group_Id "ID", sg.Society_Group_Desc "Society", 
   RTRIM(pl.Player_First_Name) + " " + pl.Player_Last_Name AS "Name", 
   pl.Date_Of_Birth AS "DOB"
FROM Society_Groups sg, Players pl
WHERE sg.Society_Group_Id = pl.Society_Group



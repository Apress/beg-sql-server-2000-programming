----------------------------------------
-- Page 442 : Try It Out - Top n PERCENT
----------------------------------------

SELECT TOP 17 PERCENT * FROM Society_Groups
SELECT TOP 17 PERCENT * FROM Society_Groups WHERE SOCIETY_GROUP_ID < 6 
   ORDER BY SOCIETY_GROUP_ID DESC


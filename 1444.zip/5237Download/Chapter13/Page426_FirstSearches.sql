----------------------------------------------------
-- Page 426 : Try It Out - The First Set of Searches
----------------------------------------------------

-- BULLET POINT 3

SELECT Player_First_Name, Games_Played FROM Players

-- BULLET POINT 5

SELECT Player_First_Name AS "First name", Games_Played AS Played 
FROM Players


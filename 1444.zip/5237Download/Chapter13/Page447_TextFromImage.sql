-----------------------------------------------------------------
-- Page 447 : Try It Out - Retrieving Text From an Image Datatype.
-----------------------------------------------------------------

-- BULLET POINT 1

DECLARE @ptr VARBINARY(16)
SELECT @ptr=TEXTPTR(Photograph)
FROM Players WHERE Player_Id = 2

-- BULLET POINT 2

READTEXT Players.Photograph @ptr 0 79

-- BULLET POINT 4

SELECT  CHAR(CAST(0x43 as int)) + CHAR(CAST(0x3A as int)) + 
CHAR(CAST(0x5C as int)) + CHAR(CAST(0x50 as int)) + CHAR(CAST(0x72 as int)) 
   + CHAR(CAST(0x6F as int)) + CHAR(CAST(0x67 as int)) 
   + CHAR(CAST(0x72 as int)) + CHAR(CAST(0x61 as int)) 
   + CHAR(CAST(0x6D as int)) + CHAR(CAST(0x20 as int))

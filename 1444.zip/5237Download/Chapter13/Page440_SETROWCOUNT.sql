---------------------------------------
-- Page 440 : Try It Out - SET ROWCOUNT
---------------------------------------

SELECT * FROM Society_Groups
SET ROWCOUNT 3
SELECT * FROM Society_Groups
SET ROWCOUNT 0
SELECT * FROM Society_Groups

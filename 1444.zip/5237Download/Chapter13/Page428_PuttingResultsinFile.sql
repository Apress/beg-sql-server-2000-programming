------------------------------------------------------
-- Try It Out - Putting the Results in Text and a File
------------------------------------------------------


-- BULLET POINT 2

SELECT Player_First_Name As "First name", Games_Played AS Played 
FROM Players


-- BULLET POINT 5

SELECT Player_First_Name As "First name", Games_Played As Played 
FROM Players

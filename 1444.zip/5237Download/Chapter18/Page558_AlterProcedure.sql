-- **********************************
-- *================================*
-- *           CHAPTER 18           *
-- *================================*
-- **********************************





-- Page 558 : Try It Out - Alter Procedure

-- BULLET POINT 2

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER  PROCEDURE [sp_Insert_A_Player]
   (@iSociety_Group    [int],
   @vPlayer_First_Name [varchar](50),
   @vPlayer_Last_Name  [varchar](50),
   @sdDate_Of_Birth    [smalldatetime],
   @tiGames_played     [tinyint],
   @siPoints_Scored    [smallint],
   @imPhotograph       [image])
AS INSERT INTO Players
   ( [Society_Group],
   [Player_First_Name],
   [Player_Last_Name],
   [Date_Of_Birth],
   [Games_played],
   [Points_Scored],
   [Has_Left_The_Club],
   [Photograph]) 

VALUES 
   (@iSociety_Group,
   @vPlayer_First_Name,
   @vPlayer_Last_Name,
   @sdDate_Of_Birth,
   @tiGames_played,
   @siPoints_Scored,
   0,
   @imPhotograph)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- BULLET POINT 3

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER  PROCEDURE [sp_Insert_A_Player]
   (@iSociety_Group    [int],
   @vPlayer_First_Name [varchar](50),
   @vPlayer_Last_Name  [varchar](50),
   @sdDate_Of_Birth    [smalldatetime],
   @tiGames_played     [tinyint],
   @siPoints_Scored    [smallint],
   @vPhotograph_Path   [varchar](100))

-- BULLET POINT 4


DECLARE @New_Player_Id int
DECLARE @Photo_Pointer varbinary(16)
DECLARE @Error_Value int
DECLARE @Rows int 


-- BULLET POINT 5

AS INSERT INTO Players
   ( [Society_Group],
    [Player_First_Name],
    [Player_Last_Name],
    [Date_Of_Birth],
    [Games_played],
    [Points_Scored],
    [Has_Left_The_Club],
    [Photograph]) 
 
VALUES 
   (@iSociety_Group,
    @vPlayer_First_Name,
    @vPlayer_Last_Name,
    @sdDate_Of_Birth,
    @tiGames_played,
    @siPoints_Scored,
    0,
    0xFFFFFF)

-- BULLET POINT 6

SET @Error_Value = @@ERROR
IF NOT @Error_Value  = 0
   RETURN @Error_Value

-- BULLET POINT 7


SET @New_Player_Id = @@IDENTITY

-- BULLET POINT 8

SELECT @Photo_Pointer = TEXTPTR(Photograph)
FROM Players
WHERE Player_Id = @New_Player_Id

-- BULLET POINT 9

SET @Rows = @@ROWCOUNT
 
IF NOT @Rows = 1
   RETURN -1

-- BULLET POINT 10


WRITETEXT Players.Photograph @Photo_Pointer @vPhotograph_Path

SET @Error_Value = @@ERROR
IF NOT @Error_Value  = 0
   RETURN @Error_Value

-- BULLET POINT 11

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE [sp_Insert_A_Player]
   (@iSociety_Group      [int],
   @vPlayer_First_Name   [varchar](50),
   @vPlayer_Last_Name    [varchar](50),
   @sdDate_Of_Birth      [smalldatetime],
   @tiGames_played       [tinyint],
   @siPoints_Scored      [smallint],
   @vPhotograph_Path     [varchar] (100))
AS INSERT INTO Players
   ([Society_Group],
   [Player_First_Name],
   [Player_Last_Name],
   [Date_Of_Birth],
   [Games_played],
   [Points_Scored],
   [Has_Left_The_Club],
   [Photograph]) 

VALUES 
   (@iSociety_Group,
   @vPlayer_First_Name,
   @vPlayer_Last_Name,
   @sdDate_Of_Birth,
   @tiGames_played,
   @siPoints_Scored,
   0,
   0xFFFFFF)

DECLARE @New_Player_Id int
DECLARE @Photo_Pointer varbinary(16)
DECLARE @Error_Value int
DECLARE @Rows int 

SET @Error_Value = @@ERROR
IF NOT @Error_Value  = 0
   RETURN @Error_Value
SET @New_Player_Id = @@IDENTITY
SELECT @Photo_Pointer = TEXTPTR(Photograph)
FROM Players
WHERE Player_Id = @New_Player_Id
SET @Rows = @@ROWCOUNT
 
IF NOT @Rows = 1
   RETURN -1
WRITETEXT Players.Photograph @Photo_Pointer @vPhotograph_Path

SET @Error_Value = @@ERROR
IF NOT @Error_Value  = 0
   RETURN @Error_Value
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- Now execute the code!


-- BULLET POINT 13


sp_Insert_A_Player @iSociety_Group=1,
   @vPlayer_First_Name="Glen",
   @vPlayer_Last_Name="Harding",
   @sdDate_Of_Birth="23 September 1961",
   @tiGames_played=0,
   @siPoints_Scored=0,
   @vPhotograph_Path="C:\Program Files\Microsoft SQL 
                         Server\MSSQL\Data\Wrox_Golf_Results\Images\ja.bmp"

-- BULLET POINT 14

SELECT Player_First_Name,Photograph FROM Players
WHERE  Player_Last_Name = "Atkins" OR Player_Last_Name = "Harding"



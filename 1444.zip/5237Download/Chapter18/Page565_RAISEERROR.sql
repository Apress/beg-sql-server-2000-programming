-- Page 565 : Try It Out - RAISERROR

-- BULLET POINT 8


SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON 
GO

ALTER      PROCEDURE sp_Insert_New_Game 
@SocietyGroup INT, @DatePlayed SMALLDATETIME, @Opposition VARCHAR(50),
@Home BIT, @Points_For INT, @Points_Against INT = 0
 -- , @ErrorCode INT OUTPUT
AS
DECLARE @MatchId INT

IF @SocietyGroup < 1
   BEGIN
      RAISERROR(50001,16,1,"@SocietyGroup - Society Group < 1")
      -- SET @ErrorCode = 1
      RETURN -1
   END
IF @DatePlayed > GETDATE()
   BEGIN
      RAISERROR(50001,16,1,"@DatePlayed - Date Played is in the future")
      -- SET @ErrorCode = 2
      RETURN -1
   END
IF LEN(@Opposition) = 0
   BEGIN
      RAISERROR(50001,16,1,"@Opposition - No opposition has been entered")
      -- SET @ErrorCode = 3
      RETURN -1
   END
IF @Points_For < 0 OR @Points_For > 3
   BEGIN
      RAISERROR(50001,16,1,"@Points_For - The wrong number of points for the
         match have been entered")
      -- SET @ErrorCode = 4
      RETURN -1
   END

IF @Points_Against < 0 OR @Points_Against > 3
   BEGIN
      RAISERROR(50001,16,1,"@Points_Against - The wrong number of points for
         the match have been entered")
      -- SET @ErrorCode = 5
      RETURN -1
   END


-- All the parameters are okay, so proceed

INSERT INTO Matches (Society_Group_Id, Date_Played, Opposition_Name, Home,
         Points_For, Points_Against)
      VALUES(@SocietyGroup, @DatePlayed, @Opposition, @Home, @Points_For,
         @Points_Against)

-- BULLET POINT 9

SET @MatchId = @@IDENTITY

RETURN @MatchId

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- End of the stored procedure

-- BULLET POINT 10

SET QUOTED_IDENTIFIER OFF
GO

DECLARE @Ret INT
DECLARE @RetStatus INT
EXEC @RetStatus = sp_Insert_New_Game 0,"24 Mar 2003","",1,-1,4
SELECT @RetStatus
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2003","",1,-1,4
SELECT @RetStatus
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","",1,-1,4
SELECT @RetStatus
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","Symington Junior Golfers",1,-1,4
SELECT @RetStatus
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","Symington Junior Golfers",1,0,4
SELECT @RetStatus

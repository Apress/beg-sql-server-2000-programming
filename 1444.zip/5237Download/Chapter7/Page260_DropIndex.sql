USE Wrox_Golf_Results
DROP INDEX IX_Match_Scores_InScoreOrder 
GO
DROP INDEX IX_Match_Scores_PlayersScoresInOrder
GO

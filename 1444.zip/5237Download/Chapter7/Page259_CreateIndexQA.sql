USE Wrox_Golf_Results
CREATE CLUSTERED INDEX 
   IX_Match_Scores_InScoreOrder 
   ON Match_Scores (Match_Id, Score_Time) 
   ON [PRIMARY]
GO
CREATE UNIQUE INDEX 
   IX_Match_Scores_PlayersScoresInOrder
   ON Match_Scores (Player_Id, Match_Id, Score_Time) 
   ON [PRIMARY]
GO

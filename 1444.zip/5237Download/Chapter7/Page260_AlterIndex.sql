USE Wrox_Golf_Results
DROP INDEX Match_Scores.IX_Match_Scores_InScoreOrder
GO
CREATE CLUSTERED INDEX 
   IX_Match_Scores_InScoreOrder 
   ON Match_Scores (Match_Id, Score_Time) 
   ON [PRIMARY]
GO
DROP INDEX Match_Scores.IX_Match_Scores_PlayersScoresInOrder
GO
CREATE UNIQUE INDEX 
   IX_Match_Scores_PlayersScoresInOrder
   ON Match_Scores (Player_Id, Match_Id, Score_Time) 
   ON [PRIMARY]
GO

-- =============================================
-- Page 549 : Try It Out - Using the CASE Statement
-- =============================================

-- BULLET POINT 1

SET QUOTED_IDENTIFIER OFF
GO

-- BULLET POINT 2

CREATE PROCEDURE sp_Win_Lose_Or_Draw 
   @Game_Date SMALLDATETIME, 
   @Society_Group_ID INT = 1
WITH ENCRYPTION
AS
   IF @Game_Date > GETDATE()
      RETURN 1
   IF @Society_Group_ID < 0
      RETURN 2
   SELECT "Win_Lose_Or_Draw_Result" = 
   CASE WHEN Points_For > Points_Against THEN
      "Win" 
   WHEN Points_For = Points_Against THEN
      "Draw" 
   WHEN Points_For < Points_Against THEN
      "Lost"  
   END
      FROM Matches
      WHERE Society_Group_Id = @Society_Group_ID 
        AND Date_Played = @Game_Date
GO 

-- BULLET POINT 4

DECLARE @Game_Date_In smalldatetime
DECLARE @Society_Group_Id_In INT
SET @Game_Date_In = "24 March 2001"
SET @Society_Group_ID_In = 1
EXECUTE sp_Win_Lose_Or_Draw @Game_Date_In, @Society_Group_ID_In

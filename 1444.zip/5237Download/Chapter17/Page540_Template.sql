-- =============================================
-- Page 540 : Try It Out - Using a Template
-- =============================================

-- BULLET POINT 4

-- =============================================
-- Create procedure with OUTPUT Parameters
-- =============================================
-- creating the store procedure
IF EXISTS (SELECT name 
      FROM   sysobjects 
      WHERE  name = N'sp_Output_Society_Group_Bank_Balance' 
      AND      type = 'P')
    DROP PROCEDURE sp_Output_Society_Group_Bank_Balance
GO


-- BULLET POINT 5


CREATE PROCEDURE sp_Output_Society_Group_Bank_Balance 
   @Society_Group int, 
   @Bank_Balance money OUTPUT
AS
   SELECT @Bank_Balance = Bank_Balance 
      FROM Society_Groups
      WHERE Society_Group_Id = @Society_Group


-- BULLET POINT 6

   IF @@ROWCOUNT = 1
      RETURN
   SET @Bank_Balance = 0
   RETURN 1
GO
 

-- BULLET POINT 7

GRANT EXECUTE ON sp_Output_Society_Group_Bank_Balance TO PUBLIC
GO

-- BULLET POINT 8

-- =============================================
-- example to execute the store procedure - valid
-- =============================================
DECLARE @Bank_Bal money
DECLARE @Ret_Status int
EXECUTE @Ret_Status = sp_Output_Society_Group_Bank_Balance 1, @Bank_Bal OUTPUT
SELECT @Bank_Bal
SELECT @Ret_Status
GO

-- BULLET POINT 9

-- =============================================
-- example to execute the store procedure - invalid
-- =============================================
DECLARE @Bank_Bal money
DECLARE @Ret_Status int
EXECUTE @Ret_Status = sp_Output_Society_Group_Bank_Balance 0, @Bank_Bal OUTPUT
SELECT @Bank_Bal
SELECT @Ret_Status
GO

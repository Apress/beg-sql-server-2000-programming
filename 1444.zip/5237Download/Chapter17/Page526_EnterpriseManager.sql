
-- **********************************
-- *================================*
-- *           CHAPTER 17           *
-- *================================*
-- **********************************



-- Page 526 : Try it out - Using Enterprise Manager
-- As mentioned in the chapter,
-- this code contains an error....

CREATE PROCEDURE [sp_Insert_A_Player]
   (@iSociety_Group      [int],
   @vPlayer_First_Name   [varchar](50),
   @vPlayer_Last_Name    [varchar](50),
   @sdDate_Of_Birth      [smalldatetime],
   @tiGames_played       [tinyint],
   @siPoints_Scored      [smallint],
   @imPhotograph         [image])
AS INSERT INTO Players
-- We are missing ( after Players
   [Society_Group],
   [Player_First_Name],
   [Player_Last_Name],
   [Date_Of_Birth],
   [Games_played],
   [Points_Scored],
   [Has_Left_The_Club],
   [Photograph]) 

VALUES 
   (@iSociety_Group,
   @vPlayer_First_Name,
   @vPlayer_Last_Name,
   @sdDate_Of_Birth,
   @tiGames_played,
   @siPoints_Scored,
   0,
   @imPhotograph)


-- This is the corrected code!
CREATE PROCEDURE [sp_Insert_A_Player]
   (@iSociety_Group       [int],
    @vPlayer_First_Name    [varchar](50),
    @vPlayer_Last_Name    [varchar](50),
    @sdDate_Of_Birth    [smalldatetime],
    @tiGames_played       [tinyint],
    @siPoints_Scored    [smallint],
    @imPhotograph       [image])

AS INSERT INTO Players
    ( [Society_Group],
    [Player_First_Name],
    [Player_Last_Name],
    [Date_Of_Birth],
    [Games_played],
    [Points_Scored],
    [Has_Left_The_Club],
    [Photograph]) 
 
VALUES 
   (@iSociety_Group,
    @vPlayer_First_Name,
    @vPlayer_Last_Name,
    @sdDate_Of_Birth,
    @tiGames_played,
    @siPoints_Scored,
    0,
    @imPhotograph)

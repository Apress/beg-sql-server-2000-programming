-- Page 530: Try It Out - Using a Wizard


-- BULLET POINT 14

sp_Update_Bank_Balance 1, 1000
SELECT Bank_Balance
FROM Society_Groups
WHERE Society_Group_Id = 1

-- BULLET POINT 16

sp_Update_Bank_Balance @Bank_Balance_2 = 3000, @Society_Group_Id_1 = 2
SELECT Bank_Balance
FROM Society_Groups
WHERE Society_Group_Id = 2

-- BULLET POINT 18

sp_Update_Bank_Balance @Bank_Balance_2 = 3000, @Society_Group_Id_1 = 57
SELECT Bank_Balance
FROM Society_Groups
WHERE Society_Group_Id = 57
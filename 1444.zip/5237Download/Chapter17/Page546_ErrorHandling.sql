-- =============================================
-- Page 546 : Try It Out - Error Handling
-- =============================================

-- BULLET POINT 1

CREATE PROCEDURE sp_Insert_New_Game 
                 @SocietyGroup INT, 
                 @DatePlayed SMALLDATETIME, 
                 @Opposition VARCHAR(50), 
                 @Home BIT, 
                 @Points_for INT,
                 @Points_Against INT, 
                 @ErrorCode INT OUTPUT
AS
-- BULLET POINT 2
IF @SocietyGroup < 1
   BEGIN
      SET @ErrorCode = 1
      RETURN -1
   END
IF @DatePlayed > GETDATE()
   BEGIN
      SET @ErrorCode = 2
      RETURN -1
   END
IF LEN(@Opposition) = 0
   BEGIN
      SET @ErrorCode = 3
      RETURN -1
   END
IF @Points_For < 0 OR @Points_For > 3
   BEGIN
      SET @ErrorCode = 4
      RETURN -1
   END
IF @Points_Against < 0 OR @Points_Against > 3
   BEGIN
      SET @ErrorCode = 5
      RETURN -1
   END



-- BULLET POINT 3

INSERT INTO Matches (Society_Group_Id, Date_Played, Opposition_Name, 
                     Home, Points_For, Points_Against)
       VALUES       (@SocietyGroup, @DatePlayed, @Opposition, @Home, 
                     @Points_For, @Points_Against)


-- END OF STORED PROCEDURE


-- BULLET POINT 5 - Checking the error codes

SET QUOTED_IDENTIFIER OFF
GO

DECLARE @Ret INT
DECLARE @RetStatus INT
EXEC @RetStatus = sp_Insert_New_Game 0,"24 Mar 2003","",1,-1,4,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2003","",1,-1,4,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","",1,-1,4,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","Symington Junior Golfers",1,-1,4,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","Symington Junior Golfers",1,0,4,@Ret OUTPUT
SELECT @RetStatus,@Ret



-- BULLET POINT 7 - Inserting some data


DECLARE @Ret INT
DECLARE @RetStatus INT
EXEC @RetStatus = sp_Insert_New_Game 1,"24 Mar 2001","The Wrox Hackers",1,3,0,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"31 Mar 2001","The Vertigo Vikings",0,1,1,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"7 Apr 2001","The Scottish Claymores",1,0,3,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"14 Apr 2001","Bedford Charity Golfers",1,3,0,@Ret OUTPUT
SELECT @RetStatus,@Ret
EXEC @RetStatus = sp_Insert_New_Game 1,"21 apr 2001","Symington Junior Golfers",0,1,1,@Ret OUTPUT
SELECT @RetStatus,@Ret

-- Page 640 : Try It Out - Dealing with Updates

-- BULLET POINT 2

CREATE  TRIGGER tgUpdMatches
ON Matches
FOR  UPDATE  


-- BULLET POINT 3

AS 
BEGIN
   DECLARE @Points_Against_Before int,@Points_For_Before INT
   DECLARE @Points_Against_After int,@Points_For_After INT
   DECLARE @Game_Won_Before int, @Game_Drawn_Before INT
   DECLARE @Game_Lost_Before INT
   DECLARE @Game_Won_After INT, @Game_Drawn_After int, @Game_Lost_After INT
   DECLARE @Society_Group INT


-- BULLET POINT 4

   -- First take the details of what was there before
   SELECT @Points_For_Before = Points_For,
      @Points_Against_Before = Points_Against,
      @Society_Group = Society_Group_Id
   FROM DELETED

-- BULLET POINT 5

  -- Required in case this is the first match. No DELETED record
   SET @Game_Lost_Before = 0
   SET @Game_Won_Before = 0
   SET @Game_Drawn_Before = 0
   

-- BULLET POINT 6

   IF (@Points_For_Before < @Points_Against_Before)
      BEGIN
         SET @Game_Lost_Before = 1
      END
   ELSE 
      IF (@Points_For_Before > @Points_Against_Before) 
         BEGIN
            SET @Game_Won_Before = 1
         END
      ELSE
         IF (@Points_For_Before = @Points_Against_Before 
         AND @Points_For_Before > 0 AND @Points_Against_Before > 0) 
            BEGIN
               SET @Game_Drawn_Before = 1
            END

-- BULLET POINT 7

   -- Now take what is there after which will give the difference
   SELECT @Points_For_After = Points_For,
      @Points_Against_After = Points_Against,
      @Society_Group = Society_Group_Id
   FROM INSERTED

   -- cater for any backouts to make the score 0-0
   SET @Game_Won_After = 0
   SET @Game_Lost_After = 0
   SET @Game_Drawn_After = 0


-- BULLET POINT 8

   IF (@Points_For_After < @Points_Against_After)
      BEGIN
         SET @Game_Lost_After = 1
      END
   ELSE 
      IF (@Points_For_After > @Points_Against_After) 
         BEGIN
            SET @Game_Won_After = 1
         END
      ELSE
         IF (@Points_For_After = @Points_Against_After 
         AND @Points_For_After > 0 AND @Points_Against_After > 0) 
            BEGIN
               SET @Game_Drawn_After = 1
            END

-- BULLET POINT 9

      UPDATE Society_Groups
      SET Games_Won = Games_Won + @Game_Won_After - @Game_Won_Before,
         Games_Drawn = Games_Drawn + @Game_Drawn_After - @Game_Drawn_Before,
         Games_Lost = Games_Lost + @Game_Lost_After - @Game_Lost_Before,
         Scored_For = Scored_For + (@Points_For_After - @Points_For_Before),
         Scored_Against = Scored_Against + _
                           (@Points_Against_After - @Points_Against_Before)
   WHERE Society_Group_Id = @Society_Group
 
END


-- BULLET POINT 11

UPDATE Society_Groups
SET Games_Played = 1, Games_Won = 1,Scored_For = 3
WHERE Society_Group_Id = 2

-- BULLET POINT 12

sp_Insert_Match_Score    @Match_ID=6, @Player_Id=3, @Score_Time = "5 May 2001 14:37:27", @Points = 0

-- BULLET POINT 13

SELECT * FROM Match_Scores
SELECT Match_Id,Points_For, Points_Against 
FROM Matches
SELECT Games_Won, Games_Drawn, Games_Lost, Scored_For, Scored_Against 
FROM Society_Groups WHERE Society_Group_id = 2

-- BULLET POINT 15


sp_Insert_Match_Score 6,2,"5 May 2001 14:45:27",3

SELECT * from Match_Scores
SELECT Match_Id,Points_For, Points_Against 
FROM Matches
SELECT Games_won, Games_Drawn, Games_Lost, Scored_For, Scored_Against 
FROM Society_Groups WHERE Society_Group_id = 2 


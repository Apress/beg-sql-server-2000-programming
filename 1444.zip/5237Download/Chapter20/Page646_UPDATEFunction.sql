-- PAGE 646 : Try It Out - UPDATE() Function


-- BULLET POINT 3


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


ALTER   TRIGGER tgUpdMatches
ON Matches
FOR  UPDATE  
AS 
   IF UPDATE(Points_For) OR UPDATE(Points_Against)
   BEGIN
      DECLARE @Points_Against_Before INT,@Points_For_Before INT
      DECLARE @Points_Against_After INT,@Points_For_After INT
      DECLARE @Game_Won_Before INT, @Game_Drawn_Before INT,
         @Game_Lost_Before INT
      DECLARE @Game_Won_After INT, @Game_Drawn_After INT, 
         @Game_Lost_After INT
      DECLARE @Society_Group INT
   
      -- First take the details of what was there before
      SELECT    @Points_For_Before = Points_For,
         @Points_Against_Before = Points_Against,
         @Society_Group = Society_Group_Id
      FROM DELETED
      -- Required in case this is the first match. No DELETED record
      SET @Game_Lost_Before = 0
      SET @Game_Won_Before = 0
      SET @Game_Drawn_Before = 0
      IF (@Points_For_Before < @Points_Against_Before)
         BEGIN
            SET @Game_Lost_Before = 1
         END
      ELSE 
         IF (@Points_For_Before > @Points_Against_Before) 
            BEGIN
               SET @Game_Won_Before = 1
            END
         ELSE
            IF (@Points_For_Before = @Points_Against_Before 
            AND @Points_For_Before > 0 AND @Points_Against_Before > 0) 
               BEGIN
                  SET @Game_Drawn_Before = 1
               END
      -- Now take what is there after which will give the difference
      SELECT    @Points_For_After = Points_For,
         @Points_Against_After = Points_Against,
         @Society_Group = Society_Group_Id
      FROM INSERTED
   
      -- cater for any backouts to make the score 0-0
      SET @Game_Won_After = 0
      SET @Game_Lost_After = 0
      SET @Game_Drawn_After = 0
   
      IF (@Points_For_After < @Points_Against_After)
         BEGIN
            SET @Game_Lost_After = 1
         END
      ELSE 
         IF (@Points_For_After > @Points_Against_After) 
            BEGIN
               SET @Game_Won_After = 1
            END
         ELSE
            IF (@Points_For_After = @Points_Against_After)
/*
This next line is not required any longer because we know for a fact that the points 
have been updated and so therefore if the points match, then they must be more than 0. 
*/

--          AND @Points_For_After > 0 AND @Points_Against_After > 0) 
               BEGIN
                  SET @Game_Drawn_After = 1
               END
   
         UPDATE Society_Groups
         SET Games_Won = Games_Won + @Game_Won_After - @Game_Won_Before,
             Games_Drawn = Games_Drawn + @Game_Drawn_After - @Game_Drawn_Before,
             Games_Lost = Games_Lost + @Game_Lost_After - @Game_Lost_Before,
             Scored_For = Scored_For + (@Points_For_After - @Points_For_Before),
             Scored_Against = Scored_Against + (@Points_Against_After - @Points_Against_Before)
      WHERE Society_Group_Id = @Society_Group
   RAISERROR ('Updated Society Groups' ,0,1)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- BULLET POINT 5

sp_Insert_Match_Score 6,4,"5 May 2001 14:54:27",0

SELECT * FROM Match_Scores
SELECT Match_Id,Points_For, Points_Against 
FROM Matches
SELECT Games_won, Games_Drawn, Games_Lost, Scored_For, Scored_Against 
FROM Society_Groups WHERE Society_Group_id = 2

-- BULLET POINT 8

UPDATE Matches
   Set Opposition_Name = "The Fat Belly's"
WHERE Match_Id = 6

SELECT * FROM Match_Scores
SELECT Match_Id,Points_For, Points_Against 
FROM Matches
SELECT Games_won, Games_Drawn, Games_Lost, Scored_For, Scored_Against 
FROM Society_Groups WHERE Society_Group_id = 2





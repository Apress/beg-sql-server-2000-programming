
-- **********************************
-- *================================*
-- *           CHAPTER 20           *
-- *================================*
-- **********************************





-- Page 636 : Try It Out - Creating a Trigger in Query Analyzer




-- =============================================
-- Create trigger basic template(After trigger)
-- =============================================
IF EXISTS (SELECT name 
   FROM   sysobjects 
   WHERE  name = N'<trigger_name, sysname, trig_test>' 
   AND    type = 'TR')
    DROP TRIGGER <trigger_name, sysname, trig_test>
GO

CREATE TRIGGER <trigger_name, sysname, trig_test>
ON <table_name, sysname, pubs.dbo.sales>
FOR DELETE, INSERT, UPDATE 
AS 
BEGIN
   RAISERROR (50009, 16, 10)
END
GO

-- BULLET POINT 3

-- =============================================
-- Create trigger basic template(After trigger)
-- =============================================
IF EXISTS (SELECT name 
   FROM   sysobjects 
   WHERE  name = "tgInsMatch_Scores" 
   AND    type = 'TR')
    DROP TRIGGER tgInsMatch_Scores
GO

CREATE TRIGGER tgInsMatch_Scores
ON Match_Scores
FOR INSERT 
AS 
BEGIN
   RAISERROR (50009, 16, 10)
END
GO
 
-- BULLLET POINT 4

- =============================================
-- Create trigger basic template(After trigger)
-- =============================================
IF EXISTS (SELECT name 
   FROM   sysobjects 
   WHERE  name = "tgInsMatch_Scores" 
   AND    type = 'TR')
    DROP TRIGGER tgInsMatch_Scores
GO

CREATE TRIGGER tgInsMatch_Scores
ON Match_Scores
FOR  INSERT 
AS 
BEGIN
   DECLARE @Points_Against int
   DECLARE @Points_For int
   DECLARE @Match_Id int
   SELECT @Points_Against = 
      CASE WHEN Score_Points = 1 
           THEN 1
           ELSE 3 - Score_Points
      END,
      @Points_For = Score_Points,
      @Match_Id = Match_Id 
   FROM INSERTED

   -- There will be a Matches record already set up
   UPDATE Matches
      SET Points_For = Points_For + @Points_For,
          Points_Against = Points_Against + @Points_Against
      WHERE Match_Id = @Match_Id
END
GO

-- BULLET POINT 5
 

CREATE PROCEDURE sp_Insert_Match_Score
   @Match_Id int, @Player_Id int, @Score_Time datetime, @Points tinyint
AS
BEGIN
   --insert the values into the (in order) match_id, player_id, 
   --score_time and scored_points columns
   INSERT INTO Match_Scores VALUES
   (@Match_Id, @Player_Id, @Score_Time, @Points)

END
GO

-- BULLET POINT 6


DECLARE @Id INT
DECLARE @ErrorCode INT
EXEC @Id = sp_Insert_New_Game 2,"5 May 2001", "The Chieftan Coach",1,0,0
SELECT @Id

- BULLET POINT 7


sp_Insert_Match_Score    @Match_ID=6, @Player_Id=1, @Score_Time = "5 May 2001 14:32:27", @Points = 3

-- BULLET POINT 8


SELECT * FROM Match_Scores
SELECT Match_Id,Points_For, Points_Against from Matches
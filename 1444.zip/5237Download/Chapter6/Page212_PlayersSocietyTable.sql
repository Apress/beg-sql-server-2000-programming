CREATE TABLE Society_Groups (
   Society_Group_Id int IDENTITY (1, 1) NOT NULL ,
   Society_Group_Desc varchar (20) NOT NULL ,
   Society_Leader_Name varchar (50)  NOT NULL ,
   Games_Played int NOT NULL ,
   Games_Won int NOT NULL ,
   Games_Drawn int NOT NULL ,
   Games_Lost int NOT NULL ,
   Scored_For int NOT NULL ,
   Scored_Against int NOT NULL ,
   Bank_Balance money NOT NULL 
)

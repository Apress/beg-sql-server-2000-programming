-- =============================================
-- Create table with IDENTITY column
-- =============================================
IF EXISTS (SELECT name 
	   FROM   sysobjects 
	   WHERE  name = N'Players' 
	   AND 	  type = 'U')
    DROP TABLE Players
GO

create table Players (
Player_Id int IDENTITY(1, 1), 
Society_Group int NOT NULL,
Player_First_Name varchar (50) NOT NULL ,
Player_Last_Name varchar (50) NOT NULL ,
Date_Of_Birth smalldatetime NOT NULL ,
Games_played tinyint NOT NULL ,
Points_Scored smallint NOT NULL ,
Has_Left_The_Club bit NOT NULL ,
Photograph image NULL 

)
GO


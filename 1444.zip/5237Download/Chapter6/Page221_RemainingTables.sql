CREATE TABLE dbo.Matches (
	Society_Group_Id int NOT NULL ,
	Match_Id int IDENTITY (1, 1) NOT NULL ,
	Date_Played smalldatetime NOT NULL ,
	Opposition_Name varchar (50) NOT NULL ,
	Home bit NOT NULL ,
	Points_For smallint NOT NULL ,
	Points_Against smallint NOT NULL 
) 
GO

CREATE TABLE dbo.Match_Scores (
	Match_Id int NOT NULL ,
	Player_Id int NOT NULL ,
	Score_Time datetime NOT NULL ,
	Score_Points tinyint NULL 
) 
GO

CREATE TABLE dbo.Newsletters (
	Society_Group_Id int NOT NULL ,
	Date_Published smalldatetime NOT NULL ,
	Contents text NULL 
) 

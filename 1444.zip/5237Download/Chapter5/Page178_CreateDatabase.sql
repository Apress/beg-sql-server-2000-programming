CREATE DATABASE Wrox_Golf_Results
ON (NAME='Wrox_Golf_Results_Data', 
FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL\data\Wrox_Golf_Results_Data.MDF', 
SIZE=1, FILEGROWTH=10%) 
LOG ON (NAME='Wrox_Golf_Results_Log', 
FILENAME='C:\Program Files\Microsoft SQL Server\MSSQL\data\Wrox_Golf_Results_Log.LDF', 
SIZE=1, FILEGROWTH=10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO

EXEC sp_dboption 'Wrox_Golf_Results', 'autoclose', 'true'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'read only', 'false'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'dbo use', 'false'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'single', 'false'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'autoshrink', 'false'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'ANSI null default', 'false'
GO
EXEC sp_dboption 'Wrox_Golf_Results', 'quoted identifier', 'true'
GO

------------------------------------------------
--  Page 466 : Try It Out - Using a Transaction
------------------------------------------------

-- BULLET POINT 1

SET QUOTED_IDENTIFIER OFF
GO

BEGIN TRAN Restore_Value
DECLARE @ValueToUpdate VARCHAR(30)
SET @ValueToUpdate = "Security Blankets"
UPDATE Society_Groups
   SET Society_Group_Desc = @ValueToUpdate,
       Society_Leader_Name = Society_Group_Desc, Games_Won = 0
WHERE Society_Group_ID = 5
COMMIT TRAN

SELECT * FROM Society_Groups


-- BULLET POINT 2


SET QUOTED_IDENTIFIER OFF
GO

BEGIN TRAN
UPDATE Society_Groups
   SET Society_Leader_Name = "Lee Smith"
-- WHERE Society_Group_Desc = "Security blankets"

SELECT * FROM Society_Groups

--  BULLET POINT 5

ROLLBACK TRAN

SELECT * FROM Society_Groups


-- BULLET POINT 6


SET QUOTED_IDENTIFIER OFF
GO

BEGIN TRAN Restore_Value
DECLARE @ValueToUpdate VARCHAR(30)
SET @ValueToUpdate = "Security Blankets"
UPDATE Society_Groups
   SET Society_Group_Desc = @ValueToUpdate
WHERE Society_Group_ID = 5
ROLLBACK TRAN
COMMIT TRAN

SELECT Society_Group_Desc FROM Society_Groups


------------------------------------------
-- Page 459 : Try it Out - Updating Data
------------------------------------------

SET QUOTED_IDENTIFIER OFF
GO

UPDATE Society_Groups
   SET Society_Leader_Name = "Lee Smith"
WHERE Society_Group_Desc = "Security blankets"


-- BULLET POINT 6

SET QUOTED_IDENTIFIER OFF
GO

DECLARE @ValueToUpdate VARCHAR(30)
SET @ValueToUpdate = "Mick Bagram"
UPDATE Society_Groups
   SET Society_Leader_Name = @ValueToUpdate,
       Society_Group_Desc = Society_Leader_Name
WHERE Society_Group_Desc = "Security Blankets"

-- BULLET POINT 8

SELECT * FROM Society_Groups

-- BULLET POINT 10

SET QUOTED_IDENTIFIER OFF
GO
DECLARE @WrongDataType VARCHAR(20)
SET @WrongDataType = "12"
UPDATE Society_Groups
   SET Games_Won = @WrongDataType 
WHERE Society_Group_ID = 5
SELECT Society_Group_Desc, Games_Won FROM Society_Groups


-- BULLET POINT 12

SET QUOTED_IDENTIFIER OFF
GO
DECLARE @WrongDataType VARCHAR(20)
SET @WrongDataType = "10.76"
UPDATE Society_Groups
   SET Games_Won = @WrongDataType 
WHERE Society_Group_ID = 5
SELECT Society_Group_Desc, Games_Won FROM Society_Groups


-- BULLET POINT 14

UPDATE Society_Groups
   SET Games_Won = 15.75 
WHERE Society_Group_ID = 5
SELECT Society_Group_Desc, Games_Won FROM Society_Groups


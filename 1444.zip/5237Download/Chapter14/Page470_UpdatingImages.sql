------------------------------------------
-- Page 470 : Try it out - Updating Images
------------------------------------------

-- BULLLET POINT 2

DECLARE @Pointer_Value varbinary(16)

SELECT @Pointer_Value = TEXTPTR(Photograph)
FROM Players
WHERE Player_Id = 3

UPDATETEXT Players.Photograph @Pointer_Value 0 NULL "C:\Program Files\Microsoft SQL Server\MSSQL\Data\Wrox_Golf_Results\Images\im_new.bmp"
 


